# Empty.
c = get_config()
c.TerminalIPythonApp.display_banner = False
